function execute() {
    return Response.success([
        { title: "Cập Nhật", input: "https://sayhentai.us", script: "gen.js" },
        { title: "Manhwa", input: "https://sayhentai.us/genre/manhwa", script: "gen.js" },
        { title: "Manga", input: "https://sayhentai.us/genre/manga", script: "gen.js" },
        { title: "Manhua", input: "https://sayhentai.us/genre/manhua", script: "gen.js" },
    ]);
}